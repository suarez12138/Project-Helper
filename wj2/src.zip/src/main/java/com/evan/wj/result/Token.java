package com.evan.wj.result;

import java.util.List;

public class Token {
    private List<String> roles;
    private String name;

    public Token(String name) {
        this.name = name;
    }

    public List<String> getRoles() {
        return roles;
    }

    public void setRoles(List<String> roles) {
        this.roles = roles;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
